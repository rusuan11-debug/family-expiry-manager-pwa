import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDuration, isValidDate, effectiveExpiry, daysRemaining,
  expiryStatus, parseLabelDates, analyzeIngredients, makeEmptyProduct,
  validateProduct, CATEGORIES
} from '../core.js';

test('validates real calendar dates and rejects impossible dates', () => {
  assert.equal(isValidDate('2026-11-24'), true);
  assert.equal(isValidDate('2026-02-29'), false);
  assert.equal(isValidDate('2024-02-29'), true);
  assert.equal(isValidDate('2026-13-01'), false);
});

test('adds days, months and years with month-end clamping', () => {
  assert.equal(addDuration('2026-01-31', 1, 'months'), '2026-02-28');
  assert.equal(addDuration('2024-02-29', 1, 'years'), '2025-02-28');
  assert.equal(addDuration('2026-12-31', 1, 'days'), '2027-01-01');
});

test('uses printed expiry first and earlier opened expiry when applicable', () => {
  const p = { productionDate: '2026-01-01', shelfLifeValue: 12, shelfLifeUnit: 'months', printedExpiryDate: '2026-12-31', opened: true, openedDate: '2026-11-01', openedShelfLifeValue: 30, openedShelfLifeUnit: 'days' };
  assert.equal(effectiveExpiry(p), '2026-12-01');
  assert.equal(effectiveExpiry({ productionDate: '2026-01-01', shelfLifeValue: 6, shelfLifeUnit: 'months' }), '2026-07-01');
});

test('calculates day difference without daylight-saving drift', () => {
  assert.equal(daysRemaining('2026-11-27', new Date(2026, 10, 24, 23, 30)), 3);
  assert.equal(daysRemaining('2026-11-23', new Date(2026, 10, 24, 8, 0)), -1);
});

test('returns expected expiry status labels', () => {
  const now = new Date(2026, 10, 24, 12, 0);
  assert.equal(expiryStatus({ printedExpiryDate: '2026-11-24' }, now).text, '今天到期');
  assert.equal(expiryStatus({ printedExpiryDate: '2026-11-27' }, now).text, '剩余3天');
  assert.equal(expiryStatus({ printedExpiryDate: '2026-11-20' }, now).key, 'expired');
});

test('parses date candidates and labels production and expiry dates', () => {
  const dates = parseLabelDates('生产日期：2026年11月20日；保质期至：2027-11-19');
  assert.equal(dates.length, 2);
  assert.equal(dates[0].type, 'productionDate');
  assert.equal(dates[1].type, 'printedExpiryDate');
});

test('ingredient rules give cautious prompts, never an absolute safety verdict', () => {
  const result = analyzeIngredients('水、牛奶、花生', [{ id: 'infant', label: '婴幼儿（0–3岁）', active: true }]);
  assert.equal(result.level, 'warning');
  assert.ok(result.matches.length >= 2);
  assert.match(result.note, /不是医学诊断或安全保证/);
  assert.equal(analyzeIngredients('水').status, '未发现已收录提示项');
});

test('new product defaults to the agreed four-category model and validates', () => {
  const p = makeEmptyProduct();
  assert.deepEqual(CATEGORIES, ['食品饮料', '母婴用品', '护肤化妆品', '日化清洁']);
  assert.equal(p.category, '食品饮料');
  p.name = '纯牛奶';
  assert.equal(validateProduct(p), true);
  assert.throws(() => validateProduct({ ...p, name: '' }), /商品名称/);
});
